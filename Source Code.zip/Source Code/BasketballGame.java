/* * Paris Alston
   * Mr. Baker
   * 2020-2021 Computer Science Internal Assessment
   * IB Honor Code */            

public class BasketballGame
{
   public static void main(String args[])
   {
      GUI gui = new GUI();
      gui.welcomeScreen();
   }
}
import java.io.*;
import java.io.IOException;
import java.text.NumberFormat;

class Database extends Player
{
   private File myObj;
  
   public void createFile()
   {
      myObj = new File("PlayerStats.txt");
   }
  
   public void writeToFile(String name, int points, int rebounds, int steals, int fouls, double FG2, double FG3)
   {
   
      NumberFormat f = NumberFormat.getPercentInstance();
      f.setMinimumFractionDigits(0);
      try{
         FileWriter myWriter = new FileWriter("PlayerStats.txt", true);
         myWriter.write("\n" + name + ", Points: " + points + ", Rebounds: " + rebounds + " , Steals: " + steals + " , Fouls: " + fouls + " . FG2%: " + f.format(FG2) + " , FG3%: " + f.format(FG3));
         //System.out.println("Printed Name: " + name);
         myWriter.close();
      } catch (IOException e){
         System.out.println("PlayerStats.txt not found.");
         e.printStackTrace();
      }
   
   } 
  
}
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.text.NumberFormat;

public class GUI implements ActionListener
{

   private JFrame frame, manage;
   private JPanel panel, panel1;
   private JTextField inputName;
   private JLabel selectedTeam, name1, name2, name3, name4, name5, enterName, selectStat, nameI, pointMessage, message2, message3;
   private JButton startGame, team1, team2, team3, team4, backButton, nextButton, backButton2, submit, points, reboundButton, stealButton, foulButton, fgButton, viewPoints, addPoints, back, twoPointer, threePointer, missedShotButton, madeShotButton;
   private JButton viewRebounds, addRebound, viewSteals, addSteal, viewFouls, addFoul, finish, confirm, unconfirm;
   private String[] teamNames = new String[4];
   private String[] playerNames = new String[5];
   private ReadTeamsFile r;
   private boolean key = false, isThree = false, madeShot = false;
   private int num = -1;
   private int points1 = 0, reboundButton1 = 0, steals1 = 0, blocks1 = 0, fouls1 = 0;
   private double fg2 = 0, fg3 = 0;
   private String team = "", name = "", finalMessage = ""; 
   private ReadPlayerFile rp;
   private Database game;
   private SendToPlayer stp;

   public void welcomeScreen()
   {
   
      r = new ReadTeamsFile();
   
      JFrame welcomeScreen = new JFrame();
      
      ImageIcon basketball = new ImageIcon("basketball.png");
   
      JLabel welcome = new JLabel(); // Welcome
      welcome.setText("Welcome!");
      welcome.setIcon(basketball);
      welcome.setHorizontalTextPosition(JLabel.CENTER);
      welcome.setVerticalTextPosition(JLabel.TOP);
      welcome.setVisible(true);
   
      startGame = new JButton(); // Start Game
      startGame.setBounds(50, 200, 150, 100);
      startGame.addActionListener(this);
      startGame.addActionListener(e -> welcomeScreen.dispose());
      startGame.setText("Start Game");  
      
      JButton quit = new JButton(); // Quit
      quit.setBounds(250, 200, 150, 100);
      quit.addActionListener(e -> System.exit(0));
      quit.setText("Quit");         
      
      welcomeScreen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      welcomeScreen.setTitle("Welcome Screen");
      
      welcomeScreen.add(startGame);
      welcomeScreen.add(quit);
      welcomeScreen.add(welcome);
      
   
      welcomeScreen.pack();
      welcomeScreen.setResizable(true);
      welcomeScreen.setVisible(true);
      
   }
   
   
   public void teamSelection()
   {
   
      frame = new JFrame();
      
      ImageIcon basketball = new ImageIcon("basketball.png");
      JButton team1, team2, team3, team4, backButton;
   
      JLabel select = new JLabel(); // Welcome
      select.setText("Select your team!");
      select.setIcon(basketball);
      select.setHorizontalTextPosition(JLabel.CENTER);
      select.setVerticalTextPosition(JLabel.TOP);
      select.setVisible(true);
      
      team1 = new JButton(); // Brooklyn Nets
      team1.setText("" + teamNames[0]);
      team1.setBounds(50, 100, 200, 100);
     
      team2 = new JButton(); // Miami Heat
      team2.setText("" + teamNames[1]);
      team2.setBounds(250, 100, 200, 100);
      
      team3 = new JButton(); // Washington Wizards
      team3.setText("" + teamNames[2]);
      team3.setBounds(50, 200, 200, 100);
      
      team4 = new JButton(); // XXL Freshmans
      team4.setText("" + teamNames[3]); 
      team4.setBounds(250, 200, 200, 100);       
      
      backButton = new JButton(); // Go Back
      backButton.setText("Go Back");
      backButton.setBackground(Color.RED);
      backButton.setForeground(Color.RED);
      backButton.addActionListener(e -> frame.setVisible(false));
      backButton.addActionListener(e -> panel.setVisible(false));
      backButton.addActionListener(e -> welcomeScreen());
      backButton.setBounds(450, 150, 100, 50); 
      
      backButton2 = new JButton(); // change team
      backButton2.setText("Change Team");
      backButton2.setBackground(Color.RED);
      backButton2.setForeground(Color.RED);
      backButton2.setEnabled(false);
      backButton2.setBounds(100, 300, 100, 50); 
      
      nextButton = new JButton(); // Next
      nextButton.setText("Continue");
      nextButton.setBackground(Color.BLACK);
      nextButton.setForeground(Color.GREEN);
      nextButton.setEnabled(false);
      nextButton.setBounds(300, 300, 100, 50); 
   
      
      selectedTeam = new JLabel(); // Selected team: <team>
      selectedTeam.setVisible(false);
      selectedTeam.setBounds(150,0,400,100);
      
      name1 = new JLabel(); // name1
      name1.setVisible(true);
      name1.setBounds(50,0,400,100);
      
      name2 = new JLabel(); // name2
      name2.setVisible(false);
      name2.setBounds(50,50,400,100);
      
      name3 = new JLabel(); // name3
      name3.setVisible(false);
      name3.setBounds(50,100,400,100);
      
      name4 = new JLabel(); // name4
      name4.setVisible(false);
      name4.setBounds(50,150,400,100);
      
      name5 = new JLabel(); // name5
      name5.setVisible(false);
      name5.setBounds(50,200,400,100);
      
      enterName = new JLabel("Enter Name: ");
      enterName.setBounds(300,100,300,100);
      enterName.setVisible(true);
      
      inputName = new JTextField();
      inputName.setBounds(400, 140, 150, 20);
      inputName.setVisible(true);
      inputName.addActionListener(this);
      
      
      submit = new JButton("Submit");
      submit.setBounds(350,180,100,50);
      submit.setVisible(true);
      submit.setEnabled(false);
      submit.setBackground(Color.BLACK);
      submit.setForeground(Color.GREEN);
               
   // =================Action Listeners=========================//
   
      team1.addActionListener(e -> team1.setEnabled(false));
      team1.addActionListener(e -> team2.setEnabled(false));
      team1.addActionListener(e -> team3.setEnabled(false));
      team1.addActionListener(e -> team4.setEnabled(false));
      team1.addActionListener(e -> nextButton.setEnabled(true));
      team1.addActionListener(e -> backButton2.setEnabled(true));
      team1.addActionListener(e -> num = 0);
      team1.addActionListener(e -> key = true);
      team1.addActionListener(e -> selectedTeam.setText("Selected Team: " + teamNames[0]));
      team1.addActionListener(e -> selectedTeam.setVisible(true));
      team1.addActionListener(e -> team = teamNames[0]);
      team1.addActionListener(this);
      
      team2.addActionListener(e -> team1.setEnabled(false));
      team2.addActionListener(e -> team2.setEnabled(false));
      team2.addActionListener(e -> team3.setEnabled(false));
      team2.addActionListener(e -> team4.setEnabled(false));
      team2.addActionListener(e -> nextButton.setEnabled(true));
      team2.addActionListener(e -> backButton2.setEnabled(true));
      team2.addActionListener(e -> num = 1);
      team2.addActionListener(e -> key = true);
      team2.addActionListener(e -> selectedTeam.setText("Selected Team: " + teamNames[1]));
      team2.addActionListener(e -> selectedTeam.setVisible(true));
      team2.addActionListener(e -> team = teamNames[1]);
      team2.addActionListener(this);
      
      team3.addActionListener(e -> team1.setEnabled(false));
      team3.addActionListener(e -> team2.setEnabled(false));
      team3.addActionListener(e -> team3.setEnabled(false));
      team3.addActionListener(e -> team4.setEnabled(false));
      team3.addActionListener(e -> num = 2);
      team3.addActionListener(e -> key = true);
      team3.addActionListener(e -> nextButton.setEnabled(true));
      team3.addActionListener(e -> backButton2.setEnabled(true));
      team3.addActionListener(e -> selectedTeam.setText("Selected Team: " + teamNames[2]));
      team3.addActionListener(e -> selectedTeam.setVisible(true));
      team3.addActionListener(e -> team = teamNames[2]);
      team3.addActionListener(this);
      
      team4.addActionListener(e -> team1.setEnabled(false));
      team4.addActionListener(e -> team2.setEnabled(false));
      team4.addActionListener(e -> team3.setEnabled(false));
      team4.addActionListener(e -> team4.setEnabled(false));
      team4.addActionListener(e -> num = 3);
      team4.addActionListener(e -> key = true);
      team4.addActionListener(e -> nextButton.setEnabled(true));
      team4.addActionListener(e -> backButton2.setEnabled(true));
      team4.addActionListener(e -> selectedTeam.setText("Selected Team: " + teamNames[3]));
      team4.addActionListener(e -> selectedTeam.setVisible(true));
      team4.addActionListener(e -> team = teamNames[3]);
      team4.addActionListener(this);
      
      backButton2.addActionListener(e -> team1.setEnabled(true));  
      backButton2.addActionListener(e -> team2.setEnabled(true));
      backButton2.addActionListener(e -> team3.setEnabled(true));
      backButton2.addActionListener(e -> team4.setEnabled(true));
      backButton2.addActionListener(e -> backButton2.setEnabled(false));
      backButton2.addActionListener(e -> nextButton.setEnabled(false));
      
      backButton2.addActionListener(e -> team1.setVisible(true));  
      backButton2.addActionListener(e -> team2.setVisible(true));
      backButton2.addActionListener(e -> team3.setVisible(true));
      backButton2.addActionListener(e -> team4.setVisible(true));
      backButton2.addActionListener(e -> nextButton.setVisible(true));
      backButton2.addActionListener(e -> backButton.setVisible(true));
      backButton2.addActionListener(e -> name1.setVisible(false));  
      backButton2.addActionListener(e -> name2.setVisible(false));
      backButton2.addActionListener(e -> name3.setVisible(false));
      backButton2.addActionListener(e -> name4.setVisible(false));
      backButton2.addActionListener(e -> name5.setVisible(false));
      backButton2.addActionListener(e -> inputName.setVisible(false));
      backButton2.addActionListener(e -> submit.setVisible(false));
      backButton2.addActionListener(e -> enterName.setVisible(false));
      backButton2.addActionListener(e -> selectedTeam.setVisible(false));
      backButton2.addActionListener(e -> key = false);
      backButton2.addActionListener(e -> num = -1);
      backButton2.addActionListener(e -> enterName.setVisible(false));
   
      
      nextButton.addActionListener(e -> team1.setVisible(false));
      nextButton.addActionListener(e -> team2.setVisible(false));
      nextButton.addActionListener(e -> team3.setVisible(false));
      nextButton.addActionListener(e -> team4.setVisible(false));
      nextButton.addActionListener(e -> backButton.setVisible(false));
      nextButton.addActionListener(e -> nextButton.setVisible(false));
      nextButton.addActionListener(e -> team1.setVisible(false));
      nextButton.addActionListener(e -> key = false);
      nextButton.addActionListener(e -> num = -1);
      nextButton.addActionListener(this);
      nextButton.addActionListener(e -> name1.setVisible(true));
      nextButton.addActionListener(e -> name2.setVisible(true));
      nextButton.addActionListener(e -> name3.setVisible(true));
      nextButton.addActionListener(e -> name4.setVisible(true));
      nextButton.addActionListener(e -> name5.setVisible(true));
      nextButton.addActionListener(e -> selectedTeam.setVisible(false));
      nextButton.addActionListener(e -> enterName.setVisible(true));
      nextButton.addActionListener(e -> inputName.setVisible(true));
      nextButton.addActionListener(e -> submit.setVisible(true));
           
      submit.addActionListener(this);
       
   // =================Add to Panel=========================//
               
      panel = new JPanel();
      panel.add(select);
      panel.add(team1);
      panel.add(team2);
      panel.add(team3);
      panel.add(team4);
      panel.add(backButton);
      panel.add(nextButton);
      panel.add(backButton2);
      panel.add(selectedTeam);
      panel.add(name1);
      panel.add(name2);
      panel.add(name3);
      panel.add(name4);
      panel.add(name5);
     
      panel.setLayout(null);
      panel.setVisible(true);
     
      frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
      frame.setTitle("Selection");
      
      
   
      frame.add(panel);         
      frame.setSize(600,400);
      
      frame.setResizable(true);
      frame.setVisible(true);
   }
   
   
   public void nameSelection()
   {
      panel.add(enterName);
      panel.add(inputName);
      panel.add(submit);
   }
   
   public void manage(String nm, String tm)
   {
   
      manage = new JFrame();
      game = new Database();
     
      NumberFormat f = NumberFormat.getPercentInstance();
      f.setMinimumFractionDigits(0);
      
      selectStat = new JLabel("Select Stat."); // Select Stat
      selectStat.setVisible(true); 
      
      nameI = new JLabel(nm); // Name
      nameI.setVisible(true); 
      
      points = new JButton("Points"); // Points
      points.setVisible(true);
               
      viewPoints = new JButton("View Points"); // View Points
      viewPoints.setVisible(false);
     
      message2 = new JLabel(); // Made 2 points
      message2.setVisible(false);
      
      message3 = new JLabel(); // Missed 3 points
      message3.setVisible(false);
     
      addPoints = new JButton("Add Points"); // View Points
      addPoints.setVisible(false);
      
      pointMessage = new JLabel();
      pointMessage.setVisible(false);
      
      missedShotButton = new JButton("Missed Shot");
      missedShotButton.setVisible(false);
      
      madeShotButton = new JButton("Made Shot");
      madeShotButton.setVisible(false);
      
      twoPointer = new JButton("Two Points");
      twoPointer.setVisible(false);
      twoPointer.setEnabled(false);
      
      threePointer = new JButton("Three Points");
      threePointer.setVisible(false);
      threePointer.setEnabled(false);
      
      reboundButton = new JButton("Rebounds");
      reboundButton.setVisible(true);
      reboundButton.setEnabled(true);
      
      viewRebounds = new JButton("View Rebounds");
      viewRebounds.setVisible(false);
      viewRebounds.setEnabled(true);
      
      addRebound = new JButton("Add Rebounds");
      addRebound.setVisible(false);
      addRebound.setEnabled(true);
      
      stealButton = new JButton("Steals");
      stealButton.setVisible(true);
      stealButton.setEnabled(true);
      
      viewSteals = new JButton("View Steals");
      viewSteals.setVisible(false);
      viewSteals.setEnabled(true);
      
      addSteal = new JButton("Add Steals");
      addSteal.setVisible(false);
      addSteal.setEnabled(true);
      
      foulButton = new JButton("Fouls");
      foulButton.setVisible(true);
      foulButton.setEnabled(true);
      
      viewFouls = new JButton("View Fouls");
      viewFouls.setVisible(false);
      viewFouls.setEnabled(true);
      
      addFoul = new JButton("Add Fouls");
      addFoul.setVisible(false);
      addFoul.setEnabled(true);
      
      fgButton = new JButton("FG%");
      fgButton.setVisible(true);
      
      
      back = new JButton("Back"); // back
      back.setVisible(false);
      back.setForeground(Color.RED);
      
      finish = new JButton("Finish");
      finish.setVisible(true);
      finish.setEnabled(true);
      finish.setForeground(Color.GREEN);
      
      confirm = new JButton("Confirm");
      confirm.setVisible(false);
      confirm.setForeground(Color.GREEN);
      
      unconfirm = new JButton("Go Back");
      unconfirm.setVisible(false);
      unconfirm.setForeground(Color.RED);
   
    // =================Action Listeners===================//
    
      points.addActionListener(e -> viewPoints.setVisible(true));
      points.addActionListener(e -> addPoints.setVisible(true));
      points.addActionListener(e -> back.setVisible(true));
      points.addActionListener(e -> points.setEnabled(false));
      points.addActionListener(e -> addPoints.setEnabled(true));
      points.addActionListener(e -> viewPoints.setEnabled(true));
      points.addActionListener(e -> message2.setVisible(false));
      points.addActionListener(e -> message3.setVisible(false));
      points.addActionListener(e -> madeShotButton.setVisible(false));
      points.addActionListener(e -> missedShotButton.setVisible(false));
      points.addActionListener(e -> madeShotButton.setEnabled(true));
      points.addActionListener(e -> missedShotButton.setEnabled(true));
      points.addActionListener(e -> pointMessage.setVisible(false));
      points.addActionListener(e -> reboundButton.setVisible(false));
      points.addActionListener(e -> finish.setVisible(false));
      points.addActionListener(e -> foulButton.setVisible(false));
      points.addActionListener(e -> stealButton.setVisible(false));
      points.addActionListener(e -> fgButton.setVisible(false));
      
      viewPoints.addActionListener(e -> viewPoints.setVisible(false));
      viewPoints.addActionListener(e -> addPoints.setVisible(false));
      viewPoints.addActionListener(e -> back.setVisible(false));
      viewPoints.addActionListener(e -> points.setEnabled(true));
      viewPoints.addActionListener(e -> pointMessage.setText(name + " has " + points1 + " points."));
      viewPoints.addActionListener(e -> pointMessage.setVisible(true));
      viewPoints.addActionListener(e -> reboundButton.setVisible(true));
      viewPoints.addActionListener(e -> stealButton.setVisible(true));
      viewPoints.addActionListener(e -> foulButton.setVisible(true));
      viewPoints.addActionListener(e -> finish.setVisible(true));
      viewPoints.addActionListener(this);
      
      addPoints.addActionListener(e -> viewPoints.setEnabled(false));
      addPoints.addActionListener(e -> points.setEnabled(false));
      addPoints.addActionListener(e -> back.setEnabled(true));
      addPoints.addActionListener(e -> missedShotButton.setVisible(true));
      addPoints.addActionListener(e -> twoPointer.setVisible(true));
      addPoints.addActionListener(e -> threePointer.setVisible(true));
      addPoints.addActionListener(e -> madeShotButton.setVisible(true));
      addPoints.addActionListener(e -> points.setVisible(false));
      addPoints.addActionListener(e -> viewPoints.setVisible(false));
      addPoints.addActionListener(e -> addPoints.setEnabled(false));
      addPoints.addActionListener(e -> twoPointer.setEnabled(false));
      addPoints.addActionListener(e -> threePointer.setEnabled(false));
      addPoints.addActionListener(this);
      
      twoPointer.addActionListener(e -> points.setEnabled(true));
      twoPointer.addActionListener(e -> points.setVisible(true));
      twoPointer.addActionListener(e -> pointMessage.setVisible(false));
      twoPointer.addActionListener(e -> viewPoints.setVisible(false));
      twoPointer.addActionListener(e -> addPoints.setVisible(false));
      twoPointer.addActionListener(e -> back.setVisible(false));
      twoPointer.addActionListener(e -> missedShotButton.setVisible(false));
      twoPointer.addActionListener(e -> madeShotButton.setVisible(false));
      twoPointer.addActionListener(e -> twoPointer.setVisible(false));
      twoPointer.addActionListener(e -> threePointer.setVisible(false));
      twoPointer.addActionListener(e -> message2.setVisible(true));
      twoPointer.addActionListener(e -> reboundButton.setVisible(true));    
      twoPointer.addActionListener(e -> reboundButton.setEnabled(true));
      twoPointer.addActionListener(e -> stealButton.setVisible(true));
      twoPointer.addActionListener(e -> foulButton.setVisible(true));
      twoPointer.addActionListener(e -> reboundButton.setVisible(true));
      twoPointer.addActionListener(e -> fgButton.setVisible(true));
      twoPointer.addActionListener(e -> finish.setVisible(true));
      twoPointer.addActionListener(this);
      
      threePointer.addActionListener(e -> points.setEnabled(true));
      threePointer.addActionListener(e -> points.setVisible(true));
      threePointer.addActionListener(e -> pointMessage.setVisible(false));
      threePointer.addActionListener(e -> viewPoints.setVisible(false));
      threePointer.addActionListener(e -> addPoints.setVisible(false));
      threePointer.addActionListener(e -> back.setVisible(false));
      threePointer.addActionListener(e -> missedShotButton.setVisible(false));
      threePointer.addActionListener(e -> madeShotButton.setVisible(false));
      threePointer.addActionListener(e -> twoPointer.setVisible(false));
      threePointer.addActionListener(e -> threePointer.setVisible(false));
      threePointer.addActionListener(e -> message3.setVisible(true));
      threePointer.addActionListener(e -> stealButton.setVisible(true));
      threePointer.addActionListener(e -> foulButton.setVisible(true));
      threePointer.addActionListener(e -> reboundButton.setVisible(true));
      threePointer.addActionListener(e -> fgButton.setVisible(true));
      threePointer.addActionListener(e -> finish.setVisible(true));
      threePointer.addActionListener(this);
   
      back.addActionListener(e -> points.setEnabled(true));
      back.addActionListener(e -> points.setVisible(true));
      back.addActionListener(e -> pointMessage.setVisible(false));
      back.addActionListener(e -> viewPoints.setVisible(false));
      back.addActionListener(e -> addPoints.setVisible(false));
      back.addActionListener(e -> back.setVisible(false));
      back.addActionListener(e -> madeShotButton.setVisible(false));
      back.addActionListener(e -> missedShotButton.setVisible(false));  
      back.addActionListener(e -> madeShotButton.setEnabled(true));
      back.addActionListener(e -> missedShotButton.setEnabled(true)); 
      back.addActionListener(e -> twoPointer.setVisible(false));
      back.addActionListener(e -> threePointer.setVisible(false)); 
      back.addActionListener(e -> reboundButton.setVisible(true));    
      back.addActionListener(e -> reboundButton.setEnabled(true));
      back.addActionListener(e -> addRebound.setVisible(false));    
      back.addActionListener(e -> viewRebounds.setVisible(false));
      back.addActionListener(e -> stealButton.setEnabled(true));
      back.addActionListener(e -> viewSteals.setVisible(false)); 
      back.addActionListener(e -> addSteal.setVisible(false)); 
      back.addActionListener(e -> addFoul.setVisible(false)); 
      back.addActionListener(e -> viewFouls.setVisible(false)); 
      back.addActionListener(e -> foulButton.setVisible(true));
      back.addActionListener(e -> foulButton.setEnabled(true));
      back.addActionListener(e -> stealButton.setVisible(true));
      back.addActionListener(e -> stealButton.setEnabled(true));
      back.addActionListener(e -> finish.setVisible(true));
      back.addActionListener(e -> fgButton.setVisible(true));
         
      missedShotButton.addActionListener(e -> message2.setText(name + " missed a 2 pointer."));
      missedShotButton.addActionListener(e -> message3.setText(name + " missed a 3 pointer."));
      missedShotButton.addActionListener(e -> madeShotButton.setEnabled(false));
      missedShotButton.addActionListener(e -> twoPointer.setEnabled(true));
      missedShotButton.addActionListener(e -> threePointer.setEnabled(true));
      missedShotButton.addActionListener(e -> madeShot = false);
      
      madeShotButton.addActionListener(e -> message2.setText(name + " made a 2 pointer."));
      madeShotButton.addActionListener(e -> message3.setText(name + " made a 3 pointer."));
      madeShotButton.addActionListener(e -> missedShotButton.setEnabled(false));
      madeShotButton.addActionListener(e -> twoPointer.setEnabled(true));
      madeShotButton.addActionListener(e -> threePointer.setEnabled(true));
      madeShotButton.addActionListener(e -> madeShot = true);
   
      reboundButton.addActionListener(e -> viewRebounds.setVisible(true));
      reboundButton.addActionListener(e -> reboundButton.setEnabled(false));
      reboundButton.addActionListener(e -> back.setVisible(true));
      reboundButton.addActionListener(e -> points.setVisible(false));
      reboundButton.addActionListener(e -> madeShotButton.setVisible(false));
      reboundButton.addActionListener(e -> missedShotButton.setVisible(false));
      reboundButton.addActionListener(e -> addRebound.setVisible(true));
      reboundButton.addActionListener(e -> message2.setVisible(false));
      reboundButton.addActionListener(e -> message3.setVisible(false));
      reboundButton.addActionListener(e -> stealButton.setVisible(false));
      reboundButton.addActionListener(e -> foulButton.setVisible(false));
      reboundButton.addActionListener(e -> finish.setVisible(false));
      reboundButton.addActionListener(e -> fgButton.setVisible(false));
      
      viewRebounds.addActionListener(e -> reboundButton.setVisible(true));
      viewRebounds.addActionListener(e -> reboundButton.setEnabled(true));
      viewRebounds.addActionListener(e -> message2.setText(name + " has " + stp.getRebounds() + " rebounds."));
      viewRebounds.addActionListener(e -> message2.setVisible(true));
      viewRebounds.addActionListener(e -> viewRebounds.setVisible(false));
      viewRebounds.addActionListener(e -> addRebound.setVisible(false));
      viewRebounds.addActionListener(e -> points.setVisible(true));
      viewRebounds.addActionListener(e -> back.setVisible(false));
      viewRebounds.addActionListener(e -> stealButton.setVisible(true));
      viewRebounds.addActionListener(e -> foulButton.setVisible(true));
      viewRebounds.addActionListener(e -> fgButton.setVisible(true));
      viewRebounds.addActionListener(e -> finish.setVisible(true));
      
      addRebound.addActionListener(e -> reboundButton.setVisible(true));
      addRebound.addActionListener(e -> reboundButton.setEnabled(true));
      addRebound.addActionListener(e -> message2.setText(name + " rebounded the ball!"));
      addRebound.addActionListener(e -> message2.setVisible(true));
      addRebound.addActionListener(e -> viewRebounds.setVisible(false));
      addRebound.addActionListener(e -> points.setVisible(true));
      addRebound.addActionListener(e -> addRebound.setVisible(false));
      addRebound.addActionListener(e -> back.setVisible(false));
      addRebound.addActionListener(e -> stealButton.setVisible(true));
      addRebound.addActionListener(e -> foulButton.setVisible(true));
      addRebound.addActionListener(e -> reboundButton.setVisible(true));
      addRebound.addActionListener(e -> fgButton.setVisible(true));
      addRebound.addActionListener(e -> finish.setVisible(true));
      addRebound.addActionListener(this);
      
      stealButton.addActionListener(e -> viewSteals.setVisible(true));
      stealButton.addActionListener(e -> stealButton.setEnabled(false));
      stealButton.addActionListener(e -> back.setVisible(true));
      stealButton.addActionListener(e -> points.setVisible(false));
      stealButton.addActionListener(e -> addSteal.setVisible(true));
      stealButton.addActionListener(e -> message2.setVisible(false));
      stealButton.addActionListener(e -> message3.setVisible(false));
      stealButton.addActionListener(e -> reboundButton.setVisible(false));
      stealButton.addActionListener(e -> foulButton.setVisible(false));
      stealButton.addActionListener(e -> fgButton.setVisible(false));
      stealButton.addActionListener(e -> finish.setVisible(false));
   
      viewSteals.addActionListener(e -> reboundButton.setVisible(true));
      viewSteals.addActionListener(e -> reboundButton.setEnabled(true));
      viewSteals.addActionListener(e -> message2.setText(name + " has " + stp.getSteals() + " steals."));
      viewSteals.addActionListener(e -> message2.setVisible(true));
      viewSteals.addActionListener(e -> viewSteals.setVisible(false));
      viewSteals.addActionListener(e -> addSteal.setVisible(false));
      viewSteals.addActionListener(e -> points.setVisible(true));
      viewSteals.addActionListener(e -> back.setVisible(false));
      viewSteals.addActionListener(e -> stealButton.setEnabled(true));
      viewSteals.addActionListener(e -> fgButton.setVisible(true));
      viewSteals.addActionListener(e -> finish.setVisible(true));
      viewSteals.addActionListener(e -> foulButton.setVisible(true));
      
      addSteal.addActionListener(e -> reboundButton.setVisible(true));
      addSteal.addActionListener(e -> reboundButton.setEnabled(true));
      addSteal.addActionListener(e -> message2.setText(name + " stole the ball!"));
      addSteal.addActionListener(e -> message2.setVisible(true));
      addSteal.addActionListener(e -> viewSteals.setVisible(false));
      addSteal.addActionListener(e -> points.setVisible(true));
      addSteal.addActionListener(e -> addSteal.setVisible(false));
      addSteal.addActionListener(e -> back.setVisible(false));
      addSteal.addActionListener(e -> stealButton.setVisible(true));
      addSteal.addActionListener(e -> stealButton.setEnabled(true));
      addSteal.addActionListener(e -> foulButton.setVisible(true));
      addSteal.addActionListener(e -> fgButton.setVisible(true));
      addSteal.addActionListener(e -> finish.setVisible(true));
      addSteal.addActionListener(this);
   
      foulButton.addActionListener(e -> viewFouls.setVisible(true));
      foulButton.addActionListener(e -> foulButton.setEnabled(false));
      foulButton.addActionListener(e -> back.setVisible(true));
      foulButton.addActionListener(e -> points.setVisible(false));
      foulButton.addActionListener(e -> addFoul.setVisible(true));
      foulButton.addActionListener(e -> message2.setVisible(false));
      foulButton.addActionListener(e -> message3.setVisible(false));
      foulButton.addActionListener(e -> stealButton.setVisible(false));
      foulButton.addActionListener(e -> reboundButton.setVisible(false));
      foulButton.addActionListener(e -> finish.setVisible(false));
      foulButton.addActionListener(e -> fgButton.setVisible(false));
      
      viewFouls.addActionListener(e -> reboundButton.setVisible(true));
      viewFouls.addActionListener(e -> reboundButton.setEnabled(true));
      viewFouls.addActionListener(e -> message2.setText(name + " has " + stp.getFouls() + " fouls."));
      viewFouls.addActionListener(e -> message2.setVisible(true));
      viewFouls.addActionListener(e -> viewFouls.setVisible(false));
      viewFouls.addActionListener(e -> addFoul.setVisible(false));
      viewFouls.addActionListener(e -> points.setVisible(true));
      viewFouls.addActionListener(e -> back.setVisible(false));
      viewFouls.addActionListener(e -> foulButton.setEnabled(true));
      viewFouls.addActionListener(e -> points.setVisible(true));
      viewFouls.addActionListener(e -> stealButton.setVisible(true));
      viewFouls.addActionListener(e -> fgButton.setVisible(true));
      viewFouls.addActionListener(e -> finish.setVisible(true));
      
      addFoul.addActionListener(e -> reboundButton.setVisible(true));
      addFoul.addActionListener(e -> reboundButton.setEnabled(true));
      addFoul.addActionListener(e -> message2.setText(name + " fouled."));
      addFoul.addActionListener(e -> message2.setVisible(true));
      addFoul.addActionListener(e -> viewFouls.setVisible(false));
      addFoul.addActionListener(e -> points.setVisible(true));
      addFoul.addActionListener(e -> addFoul.setVisible(false));
      addFoul.addActionListener(e -> back.setVisible(false));
      addFoul.addActionListener(e -> foulButton.setEnabled(true));
      addFoul.addActionListener(e -> fgButton.setVisible(true));
      addFoul.addActionListener(e -> finish.setVisible(true));
      addFoul.addActionListener(e -> stealButton.setVisible(true));
      addFoul.addActionListener(this);
      
      fgButton.addActionListener(e -> message2.setText(name + " is shooting " + f.format(stp.getFG2()) + " from the 2pt and " + f.format(stp.getFG3()) + " from the 3pt."));
      fgButton.addActionListener(e -> message2.setVisible(true));
      fgButton.addActionListener(e -> finish.setVisible(true));
      
      finish.addActionListener(e -> points.setVisible(false));
      finish.addActionListener(e -> reboundButton.setVisible(false));
      finish.addActionListener(e -> stealButton.setVisible(false));
      finish.addActionListener(e -> foulButton.setVisible(false));
      finish.addActionListener(e -> confirm.setVisible(true));
      finish.addActionListener(e -> unconfirm.setVisible(true));
      finish.addActionListener(e -> finish.setEnabled(false));
      finish.addActionListener(e -> fgButton.setVisible(false));
      finish.addActionListener(e -> message2.setVisible(false));
      finish.addActionListener(e -> message3.setVisible(false));
      
      confirm.addActionListener(e -> manage.dispose());
      confirm.addActionListener(e -> game.writeToFile(name, stp.getPoints(), stp.getRebounds(), stp.getSteals(), stp.getFouls(), stp.getFG2(), stp.getFG3())); // name points rebounds steals fouls fg2 fg3   
      confirm.addActionListener(e -> showStatsScreen());
      
      unconfirm.addActionListener(e -> points.setVisible(true));
      unconfirm.addActionListener(e -> reboundButton.setVisible(true));
      unconfirm.addActionListener(e -> stealButton.setVisible(true));
      unconfirm.addActionListener(e -> foulButton.setVisible(true));
      unconfirm.addActionListener(e -> confirm.setVisible(false));
      unconfirm.addActionListener(e -> unconfirm.setVisible(false));
      unconfirm.addActionListener(e -> finish.setEnabled(true));
      unconfirm.addActionListener(e -> fgButton.setVisible(true));
      unconfirm.addActionListener(this);
     
      
   // =================Add to Panel=========================//   
   
      panel1 = new JPanel();
      panel1.setLayout(new FlowLayout());
      panel1.setVisible(true);
      
      panel1.add(selectStat);
      panel1.add(nameI);
      
      panel1.add(points);
      panel1.add(viewPoints);
      panel1.add(addPoints);
      panel1.add(pointMessage);
      
      panel1.add(twoPointer);
      panel1.add(threePointer);
      panel1.add(madeShotButton);
      panel1.add(missedShotButton);
      
      panel1.add(reboundButton);
      panel1.add(viewRebounds);
      panel1.add(addRebound);
      
      panel1.add(stealButton);
      panel1.add(viewSteals);
      panel1.add(addSteal);
      
      panel1.add(foulButton);
      panel1.add(viewFouls);
      panel1.add(addFoul);
      
      panel1.add(fgButton);
      
      panel1.add(message2);
      panel1.add(message3);
      panel1.add(back);
      
      panel1.add(finish);
      panel1.add(confirm);
      panel1.add(unconfirm);
      
      
      manage.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
      manage.setTitle("Manage");
      manage.add(panel1);         
      manage.setSize(600,400);
      manage.setResizable(true);
      manage.setVisible(true);
   
   }
   
   public void showStatsScreen()
   {
   
      NumberFormat f = NumberFormat.getPercentInstance();
      f.setMinimumFractionDigits(0);
   
      finalMessage += name +", Points: " + stp.getPoints() +", Rebounds: " + stp.getRebounds() + ", Steals: " + stp.getSteals() + ", Fouls: " + stp.getFouls() + ", FG2: " +  f.format(stp.getFG2())+ " FG3: " + f.format(stp.getFG3());
      
      JLabel finalStats = new JLabel(finalMessage);
      finalStats.setHorizontalTextPosition(JLabel.CENTER);
      finalStats.setVerticalTextPosition(JLabel.CENTER);
      finalStats.setVisible(true);
      
      JFrame fw = new JFrame();
      fw.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
      fw.setTitle("Final");
      fw.add(finalStats);         
      fw.setSize(500,300);
      fw.setResizable(true);
      fw.setVisible(true);
      
   }

   
   public void actionPerformed(ActionEvent e)
   {
      if(e.getSource() == startGame) // start game
      {
      
         r.readFile();
         
         for(int a = 0; a < 4; a++)
         {
            teamNames[a] = r.getSingleTeam(a);
         }
         
         teamSelection();
      }
      if(e.getSource() == team1) // brooklyn nets
      {
         r.readFile();
      }
      if(e.getSource() == team2) // miami heat
      {
         r.readFile();
      }
      if(e.getSource() == team3) // washington wizards
      {
         r.readFile();
      }
      if(e.getSource() == team4) // goats
      {
         r.readFile();
      }
      if(e.getSource() == nextButton && key) // Continue
      {
         rp = new ReadPlayerFile();
         rp.setList(teamNames[num]);
         playerNames = rp.getPlayerOne();
         
         /* for(int a = 0;  a< playerNames.length; a++)
            System.out.println(playerNames[a]);*/   
            // Tests to see all player names are added, prints in output. 
      
         name1.setText("" + playerNames[0]);
         name2.setText("" + playerNames[1]);
         name3.setText("" + playerNames[2]);
         name4.setText("" + playerNames[3]);
         name5.setText("" + playerNames[4]);
         
         nameSelection();
      }
      if(e.getSource() == inputName)
      {
         name = inputName.getText();
         submit.setEnabled(true);
      }
      
      if(e.getSource() == submit)
      {
         
         System.out.println("Entered name: " + name);
      
         if(rp.isOnTeam1(inputName.getText()))
         {
            System.out.println("Successfully found " + name);
            panel.setVisible(false);
            frame.setVisible(false);
            
            manage(inputName.getText(), team);
            stp = new SendToPlayer(inputName.getText(), team);
         }
         else
            System.out.println("Error. " + name + " not found.");
      }
      
      if(e.getSource() == twoPointer)
      {
         isThree = false;
         stp.shotAttempt(isThree, madeShot);
         
         if(madeShot)
            points1 += 2;
           
      }
      if(e.getSource() == threePointer)
      {
         isThree = true;
         stp.shotAttempt(isThree, madeShot);
         
         if(madeShot)
            points1 += 3;
      }
      if(e.getSource() == addRebound)
      {
         stp.addRebound();
      }
      if(e.getSource() == addSteal)
      {
         stp.addSteal();
      }
      if(e.getSource() == addFoul)
      {
         stp.addFoul();
      }
      
      if(e.getSource() == confirm)
      {
         
      }
              
   }
}
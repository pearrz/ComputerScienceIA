import java.util.*;

public class Player
{
   protected int PTS = 0, FOUL = 0, AST = 0, STL = 0, REB = 0;
   protected double FGA2 = 0, FGA3 = 0, FGM2 = 0, FGM3 = 0;
   private String name = ""; String team = ""; String number = "";
   
   public Player(String nm, String tm)
   {
      name += nm;
      team += tm;
   }
   
   public Player()
   {
   }
    
   public void shotAttempt(boolean isThree, boolean madeShot)
   {
      if(isThree)
      {
         if(madeShot)
         {
            PTS += 3; FGA3++; FGM3++;
            System.out.println(name + " scored a 3 pointer!");
            System.out.println(name + " has " + PTS + " points");
         //System.out.println("FGA2: " + FGA2 + "\nFGA3: " + FGA3);
         }
         if(!madeShot)
         {
            System.out.println(name + " missed a 3 pointer.");
            System.out.println(name + " has " + PTS + " points");
            FGA3++;
         // System.out.println("FGA2: " + FGA2 + "\nFGA3: " + FGA3);
         }
         
      }
      if((isThree == false))
      {
         if(madeShot)
         {
            PTS += 2; FGA2++; FGM2++;
            System.out.println(name + " scored a 2 pointer!");
            System.out.println(name + " has " + PTS + " points");
         //System.out.println("FGA2: " + FGA2 + "\nFGA3: " + FGA3);
         }
         if(!madeShot)
         {
            System.out.println(name + " missed a 2 pointer.");
            System.out.println(name + " has " + PTS + " points");
            FGA2++;
         // System.out.println("FGA2: " + FGA2 + "\nFGA3: " + FGA3);
         
         }
      }
      
      Database game = new Database();
     // game.writeToFile(name, getPoints(), getAssist(), getRebounds(), getSteals(), getFouls(), getFG2(), getFG3());
   }
   
   public void addSteal()
   {
      STL++;
      System.out.println(name + " stole the ball!");
   }
   
   public void addRebound()
   {
      REB++;
      System.out.println(name + " rebounded the ball!");
   }
   
   public void addFoul()
   {
      FOUL++;
      System.out.println(name + " fouled.");
      
   }
   
   public int getFouls()
   {    
      return FOUL;
   }
   
   public int getRebounds()
   {
      return REB; 
   }
   
   public int getPoints()
   {
      return PTS;
   }
   
   public int getSteals()
   {
      System.out.println(name + " has " + STL + " steals");
   
      return STL; 
   }
   
   public double getFG2()
   {
      
      //System.out.println("FGA: " + FGA2 + "\nFGM: " + FGM2);
      double FG2;
      if(FGM2 == 0)
      {
         FG2 = 0;
      }
       
      else
         
      {
         FG2 = (FGM2 / FGA2);
      }
      
      return FG2;
   }
   
   public double getFG3()
   {
      double FG3;
      
      if(FGM3 == 0)
         return 0;
      else
         FG3 = (FGM3 / FGA3);
      
      return FG3;
   }
   
}
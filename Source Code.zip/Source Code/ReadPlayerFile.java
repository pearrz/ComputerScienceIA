import java.util.*;
import java.io.*;

class ReadPlayerFile extends ReadTeamsFile
{
   private String[] playerNames1 = new String[5]; 
   private String team1 = "";
   private String name = "";
   
   public ReadPlayerFile()
   {
   
   }
 
   public boolean isOnTeam1(String n) // Reads player file to see if player is on team 1
   {
      boolean found = false;
   
      for(int a = 0; a < playerNames1.length; a++) // Traverse list of players
      {
      
      
         if(n.equals(playerNames1[a]))
         {
            System.out.println("Found...." + n); //
            found = true;   
            name+= n;
            break;
         }
         else
            System.out.println("Searching...." + playerNames1[a]);
      }
   
   
      return found;
   }

   
   public String getName()
   {
      return name; 
   }
  
   public void setList(String team)
   {
   
      try{
         File obj = new File(team + ".txt");
         Scanner reader = new Scanner(obj);
         int x = 0;
      
         while(reader.hasNextLine())
         {
            playerNames1[x] = reader.nextLine();
            x++;
         }
         System.out.println("Successfully loaded player names.");
         
      } catch(FileNotFoundException e) 
      {
         System.out.println("File was not found.");
         e.printStackTrace();
      }
   
   }
 
   public String getTeamOne()
   {
      return team1; 
   }
 
   public String[] getPlayerOne() // Returns list of names on team 1
   {
      return playerNames1;
   }
   
   
   
}
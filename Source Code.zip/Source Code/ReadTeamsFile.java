import java.util.*;
import java.io.*;

public class ReadTeamsFile
{
   private String[] teamNames = new String[4];
   
   public void readFile()
   {
      try{
         File myObj = new File("TeamNames.txt");
         Scanner fileReader = new Scanner(myObj);
         
         int x = 0;
         
         if(teamNames[0] == null)
         {
            System.out.println("Successfully loaded teams list.");
            while(fileReader.hasNextLine())
            {
               teamNames[x] = fileReader.nextLine();
               x++;
            }
         }
         else
         {
            return;
         }
         fileReader.close();
      } catch(FileNotFoundException e) 
      {
         System.out.println("File was not found.");
         e.printStackTrace();
      }
      
   }
   
   public String[] getTeamNames()
   {
      return teamNames; 
   }
   
   public String getSingleTeam(int a)
   {
      return teamNames[a]; 
   }
   
}

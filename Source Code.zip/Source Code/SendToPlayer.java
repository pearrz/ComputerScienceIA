public class SendToPlayer extends Player
{
   public SendToPlayer(String name, String team)
   {
      super(name,team);
   }
   
   public int getPoints()
   {
      return super.getPoints();
   }
   
   public int getRebounds()
   {
      return super.getRebounds();
   }
   
   public void addRebound()
   {
      super.addRebound();
   }
   public int getSteals()
   {
      return super.getSteals();
   }
   public void addSteal()
   {
      super.addSteal();
   }
   public void addFoul()
   {
      super.addFoul();
   }
   
   public double getFG2()
   {
      return super.getFG2();
   }
   
   public double getFG3()
   {
      return super.getFG3();
   }
   
}